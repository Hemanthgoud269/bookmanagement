package com.cg.bms.test;

import static org.junit.Assert.*;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.bms.bean.BookBean;
import com.cg.bms.exceptions.BookException;
import com.cg.bms.dao.BookDao;

public class BookDaoTest {

	static BookDao dao;
	static BookBean book;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new BookDao();
		book = new BookBean();
	}

	@Test
	public void testAddBookDetails() throws BookException {

		assertNotNull(dao.addBookDetails(book));

	}

	@Test
	public void testAddBookDetails1() throws BookException {

		book.setBookTitle("kill");
		book.setAuthor("Jashuva");
		book.setCategory("Philosophy");
		book.setPrice(220);
		book.setIsbn(2127126732);
		book.setDescription("sghhsgdghsg");
		book.setPublishDate("11/11/1111");

		// increment the number next time you test for positive test case and
		// change isbn
		assertEquals(227, dao.addBookDetails(book));

	}

	@Test
	public void testViewAll() throws BookException {
		assertNotNull(dao.viewBookDetails());
	}

	@Test
	public void testEdit() throws BookException {
		book.setBookId(184);
		book.setBookTitle("kill");
		book.setAuthor("Jashuva");
		book.setCategory("Philosophy");
		book.setPrice(220);
		book.setIsbn(2123212128);
		book.setDescription("sghhsgdghsg");
		book.setPublishDate("11/11/1111");
		assertEquals(0, dao.editBookDetails(book));
	}

	@Test
	public void testAdminDetails() throws BookException {
		book.setAdminEmail("He@gmail.com");
		book.setAdminPassword("He123");
		assertEquals(true, dao.adminLogin(book));
	}
}