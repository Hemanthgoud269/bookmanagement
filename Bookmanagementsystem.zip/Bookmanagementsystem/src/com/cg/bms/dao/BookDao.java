package com.cg.bms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;

import java.util.List;

import org.apache.log4j.Logger;

import org.apache.log4j.PropertyConfigurator;

import com.cg.bms.bean.BookBean;
import com.cg.bms.exceptions.BookException;


import com.cg.connection.DataBaseConnection;
public class BookDao implements IBookDao {
	BookBean bean = new BookBean();
	Connection connection = null;
	PreparedStatement preparedstatement = null;
	ResultSet resultset = null;
	Logger logger = Logger.getRootLogger();
	public BookDao() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}
	/*******************************************************************************************************
	 - Function Name	:	addBookDetails(BookBean bean)
	 - Input Parameters	:	BookBean bean
	 - Return Type		:	Integer
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	19/06/2019
	 - Description		:	Adding Book into the database table
	 ********************************************************************************************************/
	@Override
	public int addBookDetails(BookBean bean) throws BookException {
		connection = DataBaseConnection.getInstance().getConnection();
		int bookId = 0;
		try {
			preparedstatement = connection.prepareStatement(IQueryMapper.ADD_BOOK_DETAILS);
			preparedstatement.setString(1, bean.getBookTitle());
			preparedstatement.setString(2, bean.getAuthor());
			preparedstatement.setString(3, bean.getCategory());
			preparedstatement.setFloat(4, bean.getPrice());
			preparedstatement.setLong(5, bean.getIsbn());
			preparedstatement.setString(6, bean.getDescription());
			preparedstatement.setString(7, bean.getPublishDate());
			preparedstatement.executeUpdate();
			preparedstatement = connection.prepareStatement(IQueryMapper.GET_BOOKID);
			resultset = preparedstatement.executeQuery();

			if (resultset.next()) {
				logger.info("Succesfully added");
				bookId = resultset.getInt(1);
			}
			else {
				logger.error("Unable to add the book");
			}
		} catch (SQLException e) {
			System.err.println("error in adding details");
		}
		return bookId;
	}
	/*******************************************************************************************************
	 - Function Name	:   viewBookDetails()
	 - Input Parameters	:	
	 - Return Type		:	List
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	19/06/2019
	 - Description		:	Returns details of all the books in the database table
	 ********************************************************************************************************/
	@Override
	public List<BookBean> viewBookDetails() throws BookException {
		connection = DataBaseConnection.getInstance().getConnection();
		List<BookBean> booklist = new ArrayList<BookBean>();
		int bookcount = 0;
		ResultSet rs = null;
		try {
			preparedstatement = connection.prepareStatement(IQueryMapper.VIEW_BOOKS_DETAILS);
			rs = preparedstatement.executeQuery();
			while (rs.next()) {
				BookBean bbean = new BookBean();
				bbean.setBookId(rs.getInt(1));
				bbean.setBookTitle(rs.getString(2));
				bbean.setAuthor(rs.getString(3));
				bbean.setCategory(rs.getString(4));
				bbean.setPrice(rs.getFloat(5));
				bbean.setLastUpdated(rs.getString(6));
				bbean.setIsbn(rs.getLong(7));
				bbean.setDescription(rs.getString(8));
				bbean.setPublishDate(rs.getString(9));
				booklist.add(bbean);
				bookcount++;
				logger.info("View all book details succesfully");
			}
		} catch (SQLException sqlException) {
			logger.error("Error in closing Data base connection");
			throw new BookException("technical error");
		}
		finally {
			try {
				rs.close();
				preparedstatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new BookException("Error in closing db connection");
			}
		}
		if (bookcount == 0)
			return null;
		else
			return booklist;
	}
	/*******************************************************************************************************
	 - Function Name	:   deleteBook(integer id)
	 - Input Parameters	:	BookId
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	20/06/2019
	 - Description		:	Performs deletion of book from the database
	 ********************************************************************************************************/
	@Override
	public int deleteBook(int id) throws BookException {
		int flag = 0;

		try {
			connection = DataBaseConnection.getInstance().getConnection();

			preparedstatement = connection.prepareStatement(IQueryMapper.DELETE_BOOK_DETAILS);
			preparedstatement.setInt(1, id);
			int i = preparedstatement.executeUpdate();
			if (i >= 1) {
				logger.info("Successfully deleted a book ");
				flag = 1;
			} else {
				logger.error("Could not find a book with given bookId");

			flag = 0;
			}
		}
		catch (SQLException e) {
			logger.error("Error in closing Data base connection");
			throw new BookException(e.getMessage());
		}
		return flag;
	}
	/*******************************************************************************************************
	 - Function Name	:   editBookDetails(BookBean bean)
	 - Input Parameters	:	bean
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	20/06/2019
	 - Description		:	Performs updating of new details of the book
	 ********************************************************************************************************/
	@Override
	public int editBookDetails(BookBean bean) throws BookException {
		int queryResult = 0;
		try {
			connection = DataBaseConnection.getInstance().getConnection();
			
			preparedstatement = connection.prepareStatement(IQueryMapper.UPDATE_BOOK_DETAILS);
			preparedstatement.setString(1, bean.getBookTitle());
			preparedstatement.setString(2, bean.getAuthor());
			preparedstatement.setString(3, bean.getCategory());
			preparedstatement.setFloat(4, bean.getPrice());
			preparedstatement.setLong(5, bean.getIsbn());
			preparedstatement.setString(6, bean.getDescription());
			preparedstatement.setString(7, bean.getPublishDate());
			preparedstatement.setInt(8, bean.getBookId());
			queryResult = preparedstatement.executeUpdate();
			if (queryResult == 1) {
				logger.info("Successfully updated the new details of the book");
				System.out.println("succesfully edited");
			} else
				logger.error("Could not edit the book");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			logger.error("Error in editing the details ");
			
		}
		return queryResult;
	}
	/*******************************************************************************************************
	 - Function Name	:   searchBook(integer Id)
	 - Input Parameters	:	List
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	21/06/2019
	 - Description		:	Gathers the details of the specific book and returns in the form of list
	 ********************************************************************************************************/
	@Override
	public List<BookBean> searchBook(int Id) throws BookException {

		connection = DataBaseConnection.getInstance().getConnection();
		try {
			preparedstatement = connection.prepareStatement(IQueryMapper.SEARCH_BOOKID);

			preparedstatement.setInt(1, Id);

			resultset = preparedstatement.executeQuery();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		List<BookBean> booklist = new ArrayList<BookBean>();
	
		try {
			if (resultset.next()) {
				
				BookBean bbean = new BookBean();
				bbean.setBookId(resultset.getInt(1));
				bbean.setBookTitle(resultset.getString(2));
				bbean.setAuthor(resultset.getString(3));
				bbean.setCategory(resultset.getString(4));
				bbean.setPrice(resultset.getFloat(5));
				bbean.setLastUpdated(resultset.getString(6));
				bbean.setIsbn(resultset.getLong(7));
				bbean.setDescription(resultset.getString(8));
				bbean.setPublishDate(resultset.getString(9));
				booklist.add(bbean);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return booklist;
	}
	/*******************************************************************************************************
	 - Function Name	:   adminLogin(BookBean bean)
	 - Input Parameters	:	bean
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	21/06/2019
	 - Description		:	Checks given credentials with the database
	 ********************************************************************************************************/
	@Override
	public boolean adminLogin(BookBean bean) throws BookException {
		boolean admincheckflag = false;
		ResultSet resultset = null;
		connection = DataBaseConnection.getInstance().getConnection();
		PreparedStatement preparedstatement = null;
		try {
			preparedstatement = connection.prepareStatement(IQueryMapper.ADMIN_LOGIN_QUERY);
			preparedstatement.setString(1, bean.getAdminEmail());
			preparedstatement.setString(2, bean.getAdminPassword());
			resultset = preparedstatement.executeQuery();
			if (resultset.next()) {
				logger.info("Successfully found the details of the admin");
				admincheckflag = true;
			} else {
				logger.error("Error occurred due to incorrect credentials entered");
				admincheckflag = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return admincheckflag;
	}
	/*******************************************************************************************************
	 - Function Name	:   adminEmail(String email)
	 - Input Parameters	:	email
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	21/06/2019
	 - Description		:	Checks whether the given email is existing in database or not
	 ********************************************************************************************************/
	@Override
	public boolean adminEmail(String email) throws BookException {
		boolean adminemailflag = true;
		try {
			connection = DataBaseConnection.getInstance().getConnection();
			PreparedStatement ps = connection.prepareStatement(IQueryMapper.ADMIN_EMAIL);
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				adminemailflag = false;
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		catch(BookException e) {
			e.printStackTrace();
		}
		return adminemailflag;
	}
	@Override
	public boolean addadmin(BookBean bean) throws BookException {
		return false;
	}

}
