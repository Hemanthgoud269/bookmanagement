package com.cg.bms.dao;

public interface IQueryMapper {
	
	public static final String ADD_BOOK_DETAILS = "insert into Book_Details values(BookId_seq.nextval,?, ?, ?, ?, sysdate, ?, ?, ? )";
	
	public static final String DELETE_BOOK_DETAILS = "delete from Book_Details where Book_Id=? ";
	
	public static final String VIEW_BOOKS_DETAILS = "select *from Book_Details";
	
	public static final String GET_BOOKID = "select BookId_seq.currval from dual";
	
	public static final String SEARCH_BOOKID = "select *from Book_Details where Book_Id=?";
	
	public static final String UPDATE_BOOK_DETAILS = "update book_details set Book_title=?, author=?, category=?, price=?, last_updated=sysdate, isbn=?, description=?, publish_date=?  where book_id=?";
	
	public static final String ADMIN_LOGIN_QUERY = "select *from admindetails where emailid=? and password=? ";
	
	public static final String ADMIN_EMAIL = "select emailid from admindetails where emailid=? ";

}
