package com.cg.bms.service;

import java.util.ArrayList;
import java.util.List;

import java.util.regex.Pattern;

import com.cg.bms.bean.BookBean;
import com.cg.bms.dao.BookDao;
import com.cg.bms.exceptions.BookException;


public class BookService implements IBookService {
	BookDao dao= new BookDao();
	BookBean bean= new BookBean();
	/*******************************************************************************************************
	 - Function Name	:	addBookDetails(BookBean bean)
	 - Input Parameters	:	BookBean bean
	 - Return Type		:	Integer
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	19/06/2019
	 - Description		:	Adding Book into the database table calls BookDao method addBookDetails(bean);
	 ********************************************************************************************************/
	@Override
	public int addBookDetails(BookBean bean) throws Exception {
		
		
		int bookId=dao.addBookDetails(bean);
		return bookId;
	}
	/*******************************************************************************************************
	 - Function Name	:   editBookDetails(BookBean bean)
	 - Input Parameters	:	bean
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	20/06/2019
	 - Description		:	For updating of new details of the book, calls BookDao method addBookDetails(bean);
	 ********************************************************************************************************/
	@Override
	public int editBookDetails(BookBean bean) throws Exception {
		
		int i=dao.editBookDetails(bean);
		
	return i;
	}
	/*******************************************************************************************************
	 - Function Name	:   viewBookDetails()
	 - Input Parameters	:	
	 - Return Type		:	List
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	19/06/2019
	 - Description		:	For getting details of all the books in the database table, calls BookDao method viewBookDetails();
	 ********************************************************************************************************/
	@Override
	public List<BookBean> viewBookDetails() throws Exception {
		
		List<BookBean> books=new ArrayList<BookBean>();;
		
		books=dao.viewBookDetails();
		
		return books;
	}
	/*******************************************************************************************************
	 - Function Name	:   deleteBook(integer id)
	 - Input Parameters	:	BookId
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	20/06/2019
	 - Description		:	For deleting book details from database, calls BookDao method deleteBook(int Id)
	 ********************************************************************************************************/
	@Override
	public int deleteBook(int Id) throws Exception {
	
	
		int i=dao.deleteBook(Id);
		return i;
	
	}
	/*******************************************************************************************************
	 - Function Name	:   searchBook(integer Id)
	 - Input Parameters	:	List
	 - Return Type		:	integer
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	21/06/2019
	 - Description		:	Validates the given bookId and calls BookDao method searchBook(integer id)
	 ********************************************************************************************************/
	@Override
	public List<BookBean> searchBook(int id) throws Exception {
		
		
		List<BookBean> books=new ArrayList<BookBean>();;
	if(id<9999) {
	books=dao.searchBook(id);
	}
		else
		{
			throw new BookException("Enter natural number with less than 4 digits");
		}
	return books;
		}

	/*******************************************************************************************************
	 - Function Name	:   validateTitle(String title)
	 - Input Parameters	:	title
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given title with the specified pattern
	 ********************************************************************************************************/

	@Override
	public boolean validateTitle(String title) throws BookException {
	
		String titleRegEx = "^[A-Z]+[a-zA-Z0-9\\s]{4,30}+$";
		if (!Pattern.matches(titleRegEx, title)) {
			throw new BookException("Enter alphanumerics with minimum of five characters and first letter in uppercase");
		}
		
		return true;
	}

	/*******************************************************************************************************
	 - Function Name	:   validateAuthor(String author)
	 - Input Parameters	:	author
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given author name with the specified pattern
	 * @return 
	 ********************************************************************************************************/
	@Override
	public boolean validateAuthor(String author) throws BookException {

		String authorRegEx ="^[A-Z]+[a-zA-Z0-9\\s]{4,30}+$";
		if (!Pattern.matches(authorRegEx, author)) {
			throw new BookException("Enter alphanumerics with minimum of five characters and first letter in uppercase");
		}
		return true;

	}
	/*******************************************************************************************************
	 - Function Name	:   vaildateCategory(String category)
	 - Input Parameters	:	category
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	HEMANTH GOUD
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given category name with the specified pattern
	 * @return 
	 ********************************************************************************************************/
	@Override
	public boolean vaildateCategory(String category) throws BookException {
		
		String categoryRegEx ="^[A-Z]+[a-zA-Z0-9\\s]{1,20}+$";
		if (!Pattern.matches(categoryRegEx, category)) {
			throw new BookException("Enter alphanumerics with minimum of two characters and first letter in uppercase");
		}
		return true;

	}
	/*******************************************************************************************************
	 - Function Name	:   validatePrice(float price)
	 - Input Parameters	:	boolean
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given price with the specified conditions
	 * @return 
	 ********************************************************************************************************/
	@Override
	public boolean validatePrice(float price) throws BookException {
	
		if(price<10.00)
		{
			throw new BookException("price should not be less than 10rs");
		}
		if(price>50000.00)
		{
			throw new BookException("price should not be more than 50,000rs");
		}
		return true;

	}
	/*******************************************************************************************************
	 - Function Name	:   validateISBN(long isbn)
	 - Input Parameters	:	isbn
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given isbn with the specified conditions
	 * @return 
	 ********************************************************************************************************/
	@Override
	public boolean validateISBN(long isbn) throws BookException {
		
		
		String patternRegEx="^[0-9]{10,15}$";
		if(!Pattern.matches(patternRegEx, Long.toString(isbn)))
		{
			throw new BookException("ISBN should have minimum of 10 and maximum of 15 digits");
		}
		return true;

	}
	/*******************************************************************************************************
	 - Function Name	:   validatePublishdate(String publishDate) 
	 - Input Parameters	:	publishDate
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given publishDate with the specific pattern
	 * @return 
	 ********************************************************************************************************/
	@Override
	public boolean validatePublishdate(String publishdate) throws BookException {
		
		String dateRegEx = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[012])/(18|19|20)[0-9][0-9]$";
		 
		if (!Pattern.matches(dateRegEx, publishdate)) {
			throw new BookException("plese follow the date format of dd/mm/yyyy");
		}
		return true;

	}
	/*******************************************************************************************************
	 - Function Name	:   validateDescription(String description) 
	 - Input Parameters	:	description
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	22/06/2019
	 - Description		:	Validates given description with the specific pattern
	 * @return 
	 ********************************************************************************************************/
	@Override
	public boolean validateDescription(String description) throws BookException {
		
		String nameRegEx ="^[A-Z]+[a-zA-Z0-9\\s]{20,250}$";
		if (!Pattern.matches(nameRegEx, description)) {
			throw new BookException("Enter alphabets with munimum of twenty characters and first in uppercase");
		}
		return true;
	}
	/*******************************************************************************************************
	 - Function Name	:   checkEmailPattern(String email) 
	 - Input Parameters	:	email
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	22/06/2019
	 - Description		:	Checks the pattern of the given email
	 * @return 
	 ********************************************************************************************************/
	@Override
	public boolean checkEmailPattern(String email) throws BookException {
		String emailpattern = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		
		if (!Pattern.matches(emailpattern, email)) {
			
			throw new BookException("Enter the email in correct pattern(xxx@yyyy.com)");
		}
		return true;
	}
	/*******************************************************************************************************
	 - Function Name	:   checkPasswordPattern(String adminPassword) 
	 - Input Parameters	:	adminPassword
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	22/06/2019
	 - Description		:	Checks the pattern of the given password
	 * @return 
	 ********************************************************************************************************/

	@Override
	public boolean checkPasswordPattern(String adminpassword) throws BookException {
		String passwordRegEx="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{3,16}$";
		if (!Pattern.matches(passwordRegEx, adminpassword)) {
			
			throw new BookException(" enter the password in correct pattern(min 1 uppercase, 1 lowercase, 1 digit, max 16 characters)");
		}
		return true;
	}
	/*******************************************************************************************************
	 - Function Name	:   checkPasswordPattern(String adminPassword) 
	 - Input Parameters	:	adminPassword
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	22/06/2019
	 - Description		:	Checks the pattern of the given password
	 ********************************************************************************************************/
	@Override
	public boolean adminLogin(BookBean bean) throws Exception {
		
		boolean adminloginflag=false;
		adminloginflag=dao.adminLogin(bean);
		return adminloginflag;
	}
	/*******************************************************************************************************
	 - Function Name	:   adminEmail(String email)
	 - Input Parameters	:	email
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	22/06/2019
	 - Description		:	Checks whether the given emails exists or not by calling BookDao method adminEmail(email)
	 ********************************************************************************************************/
	@Override
	public boolean adminEmail(String email) throws Exception {
	
		boolean adminemailflag=false;
		adminemailflag=dao.adminEmail(email);
		return adminemailflag;
	}

	}

