package com.cg.bms.service;

import java.util.List;

import com.cg.bms.bean.BookBean;
import com.cg.bms.exceptions.BookException;

public interface IBookService {
public int addBookDetails(BookBean bean) throws Exception;
public int editBookDetails(BookBean bean) throws Exception;
public List<BookBean> viewBookDetails() throws Exception;
public int deleteBook(int Id) throws Exception;
public List<BookBean> searchBook(int Id) throws Exception;
public boolean validateTitle(String title) throws BookException;

public boolean validateAuthor(String author) throws BookException;
public boolean vaildateCategory(String category) throws BookException;
public boolean validatePrice(float price) throws BookException;
public boolean validateISBN(long isbn) throws BookException;
public boolean validatePublishdate(String publishdate) throws BookException;
public boolean validateDescription(String description) throws BookException;
public boolean checkEmailPattern(String email) throws BookException;
public boolean checkPasswordPattern(String adminpassword) throws BookException;
public boolean adminLogin(BookBean bean) throws Exception;
public boolean adminEmail(String email) throws Exception;
}
