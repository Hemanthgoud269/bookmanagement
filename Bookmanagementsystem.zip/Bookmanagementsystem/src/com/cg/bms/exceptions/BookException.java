package com.cg.bms.exceptions;

public class BookException extends Exception {
	private static final long serialVersionUID = 726264577455921591L;

	public BookException(String message) 
	{
		
		super(message);
	}
}
