package com.cg.bms.ui;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.bms.bean.BookBean;

import com.cg.bms.exceptions.BookException;
import com.cg.bms.service.BookService;

public class BookMain {

	//@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		BookBean bean = new BookBean();
		BookService service = new BookService();
		try {
			boolean adminLoginFlag = false;
			boolean emailCheckFlag = false;
			boolean emailFlag = false;
			do {
				try {
					System.out.println("Enter the Email");
					String adminEmail = scanner.next();
					emailCheckFlag = service.checkEmailPattern(adminEmail);
					bean.setAdminEmail(adminEmail);
					emailFlag = service.adminEmail(adminEmail);
					if (!emailFlag) {
						System.err.println("Enter an existing emailId");
					}
				} catch (BookException e) {
					System.err.println(e.getMessage());
				}
			} while (!emailCheckFlag || !emailFlag);

			boolean passwordCheckFlag = false;
			do {
				do {

					System.out.println("Enter the Password");
					try {
						String adminpassword = scanner.next();

						passwordCheckFlag = service.checkPasswordPattern(adminpassword);
						bean.setAdminPassword(adminpassword);

					} catch (BookException e) {
						System.err.println(e.getMessage());
					}
				} while (!passwordCheckFlag);

				adminLoginFlag = service.adminLogin(bean);
				if (!adminLoginFlag)
					System.err.println("Enter Correct password");
			} while (!adminLoginFlag);
			while (true) {

				System.out.println("Enter your choice");
				System.out.println(
						"1) Add new book  \n2) view all books \n3) Edit existing book   \n4) delete book \n5) exit ");

				try {
					scanner = new Scanner(System.in);
					int choice = scanner.nextInt();
					switch (choice) {
					case 1:
						try {

							String title = null;
							boolean titleflag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter the name of the book");
								try {
									title = scanner.nextLine();
									titleflag = service.validateTitle(title);
									bean.setBookTitle(title);
									break;
								} catch (BookException e) {
									System.err.println(e.getMessage());
								}

							} while (!titleflag);

							String authorName = null;
							boolean authorFlag = false;
							do {
								System.out.println("Enter name of the author of the book");
								try {
									authorName = scanner.nextLine();
									service.validateAuthor(authorName);
									authorFlag = true;
									bean.setAuthor(authorName);
									break;
								} catch (BookException e) {
									System.err.println(e.getMessage());
								}
							} while (!authorFlag);

							String category = null;
							boolean categoryFlag = false;
							do {
								System.out.println("Enter the category of the book");
								try {
									category = scanner.nextLine();
									service.vaildateCategory(category);
									categoryFlag = true;
									bean.setCategory(category);

									break;
								} catch (BookException e) {
									System.err.println(e.getMessage());
								}
							} while (!categoryFlag);

							float price;
							boolean priceFlag = false;

							do {
								System.out.println("what is the price of the book");
								try {
									scanner = new Scanner(System.in);
									DecimalFormat df = new DecimalFormat("#.##");
									price = scanner.nextFloat();
									df.format(price);

									service.validatePrice(price);
									priceFlag = true;

									bean.setPrice(price);
									break;
								}

								catch (InputMismatchException e) {
									System.err.println("Enter only digits");
								} catch (BookException e) {
									System.err.println(e.getMessage());
								}
							} while (!priceFlag);

							scanner = new Scanner(System.in);
							String description = null;
							boolean descriptionFlag = false;
							do {
								System.out.println("Enter the description");
								try {
									description = scanner.nextLine();
									service.validateDescription(description);
									descriptionFlag = true;
									bean.setDescription(description);
									break;

								} catch (BookException e) {
									System.err.println(e.getMessage());
								}

							} while (!descriptionFlag);

							boolean isbnFlag = false;
							long isbn;
							do {
								System.out.println("Enter the ISBN");
								try {
									scanner = new Scanner(System.in);
									isbn = scanner.nextLong();
									service.validateISBN(isbn);
									isbnFlag = true;

									bean.setIsbn(isbn);
									break;
								} catch (InputMismatchException e) {
									System.err.println("Enter digits only");

								} catch (BookException e) {
									System.err.println(e.getMessage());
								}
							} while (!isbnFlag);

							String publishDate = null;
							boolean publishdateFlag = false;
							do {
								System.out.println("Enter the publish date");
								try {
									publishDate = scanner.next();
									service.validatePublishdate(publishDate);
									publishdateFlag = true;
									bean.setPublishDate(publishDate);
								} catch (BookException e) {
									System.err.println(e.getMessage());
								}
							} while (!publishdateFlag);
							int bookId = service.addBookDetails(bean);
							if (bookId == 0)
								System.err.println("Could not add the book, the entered ISBN may already exists");
							else
							System.out.println("book is succesfully added with id=" + bookId);

						} catch (InputMismatchException e) {
							System.out.println("Input numbers only");
						}
						boolean choiceFlag = true;
						do {

							System.out.println("Do you wish to continue?\n Option-1)yes \n Option-2)no");
							try {
								scanner = new Scanner(System.in);
								int choice2 = scanner.nextInt();
								if (choice2 == 2) {
									System.out.println("*** Thank you *** ");
									System.exit(0);
									break;
								} else if (choice2 == 1) {
									choiceFlag = false;
								} else {
									throw new BookException("Enter option 1 or 2");
								}
							} catch (InputMismatchException e) {
								System.err.println("Enter numbers only");
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (choiceFlag);
						break;

					case 2:
						BookService service1 = new BookService();
						List<BookBean> bookdetails = new ArrayList<BookBean>();

						bookdetails = service1.viewBookDetails();

						if (bookdetails != null) {

							System.out.println(String.format("%-8s %-20s %-12s %-15s %-8s %-15s %-20s %-50s %s",
									"Book ID", "Book Title", "Author", "Category", "Price", "Last Updated", "ISBN",
									"Description", "Publish Date"));

							Iterator<BookBean> iterator = bookdetails.iterator();

							while (iterator.hasNext()) {
								BookBean bookBean = iterator.next();
								System.out.println(String.format("%-8s %-20s %-12s %-15s %-8s %-15s %-20s %-50s %s",
										bookBean.getBookId(), bookBean.getBookTitle(), bookBean.getAuthor(),
										bookBean.getCategory(), bookBean.getPrice(), bookBean.getLastUpdated(),
										bookBean.getIsbn(), bookBean.getDescription(), bookBean.getPublishDate()));
							}
						} else {

							System.out.println("\n ******No book details are inserted till now******\n");
						}
						boolean choiceFlag1 = true;
						do {
							System.out.println("Do you wish to continue?\n Option-1)yes \n Option-2)no");							scanner = new Scanner(System.in);
							try {
								int choice2 = scanner.nextInt();
								if (choice2 == 2) {
									System.out.println("*** Thank you *** ");
									System.exit(0);
									break;
								} else if (choice2 == 1) {
									choiceFlag1 = false;
								} else {
									throw new BookException("Enter option 1 or 2");
								}

							} catch (InputMismatchException e) {
								System.err.println("Enter numbers only\n");

							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (choiceFlag1);
						break;

					case 3:

						boolean bookidflag = false;

						BookService service3 = new BookService();

						do {
							try {
								scanner = new Scanner(System.in);
								System.out.println("Enter the book id");

								List<BookBean> booklist = new ArrayList<BookBean>();
								int bookId = scanner.nextInt();
								bean.setBookId(bookId);
								booklist = service3.searchBook(bookId);

								if (booklist != null) {

									Iterator<BookBean> i2 = booklist.iterator();

									if (i2.hasNext()) {
										System.out.println(i2.next());
										bookidflag = true;
									} else {
										System.err.println("enter existing book id");
									}

								}

							} catch (InputMismatchException e) {
								System.out.println("enter numbers only");

							} catch (BookException e) {
								System.err.println(e.getMessage());
							}

						} while (!bookidflag);
						scanner = new Scanner(System.in);
						String title = null;
						boolean titleflag = false;

						do {
							System.out.println("Enter the new name of the book");
							try {
								title = scanner.nextLine();
								service.validateTitle(title);
								titleflag = true;
								bean.setBookTitle(title);
								break;
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!titleflag);

						String author = null;
						boolean authorflag = false;
						do {
							System.out.println("Enter author name of the book");
							try {
								author = scanner.nextLine();
								service.validateAuthor(author);
								authorflag = true;
								bean.setAuthor(author);
								break;
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!authorflag);

						String category = null;
						boolean categoryflag = false;
						do {
							System.out.println("Enter the category of the book");
							try {
								category = scanner.nextLine();
								service.vaildateCategory(category);
								categoryflag = true;
								bean.setCategory(category);

								break;
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!categoryflag);

						float price;
						boolean priceflag = false;
						do {
							System.out.println("what is the price of the book");
							try {
								scanner = new Scanner(System.in);
								price = scanner.nextFloat();

								service.validatePrice(price);
								priceflag = true;

								bean.setPrice(price);
								break;
							}

							catch (InputMismatchException e) {
								System.err.println("Enter only digits");
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!priceflag);
						scanner = new Scanner(System.in);
						String description = null;
						boolean descriptionflag = false;
						do {
							System.out.println("Enter the description");
							try {
								description = scanner.nextLine();
								service.validateDescription(description);
								descriptionflag = true;
								bean.setDescription(description);
								break;
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!descriptionflag);
						boolean isbnflag = false;
						long isbn;
						do {
							System.out.println("Enter the ISBN");
							try {
								scanner = new Scanner(System.in);
								isbn = scanner.nextLong();
								service.validateISBN(isbn);
								isbnflag = true;

								bean.setIsbn(isbn);
								break;
							} catch (InputMismatchException e) {
								System.err.println("Enter digits only");

							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!isbnflag);
						String publishDate = null;
						boolean publishdateflag = false;
						do {
							System.out.println("Enter the publish date");
							try {
								publishDate = scanner.next();
								service.validatePublishdate(publishDate);
								publishdateflag = true;
								bean.setPublishDate(publishDate);
							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (!publishdateflag);

						int edit=service.editBookDetails(bean);
						if(edit>0)
							System.out.println("Successfully updated the new details");
						else
							System.out.println("Could not update the details");
						
						boolean choiceFlag2 = true;
						do {
							System.out.println("Do you wish to continue?\n Option-1)yes \n Option-2)no");							try {
								scanner = new Scanner(System.in);
								int choice2 = scanner.nextInt();
								if (choice2 == 2) {

									System.out.println("*** Thank you *** ");
									System.exit(0);
									break;
								} else if (choice2 == 1) {
									choiceFlag2 = false;
								} else {
									throw new BookException("Enter option 1 or 2");
								}

							} catch (InputMismatchException e) {
								System.err.println("Enter numbers only");

							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (choiceFlag2);
						break;

					case 4:
						/** Getting BookId from the user to delete **/
						int i3 = 0;
						do {
							System.out.println("Enter the book id");
							try {
								scanner = new Scanner(System.in);

								int Bookid = scanner.nextInt();
								bean.setBookId(Bookid);
								List<BookBean> booklist = new ArrayList<BookBean>();

								booklist = service.searchBook(Bookid);

								if (booklist != null) {

									Iterator<BookBean> i2 = booklist.iterator();

									if (i2.hasNext()) {
										System.out.println(i2.next());
										int a = 0;
										do {
											try {
												System.out.println(
														"Do you wish to continue deleting this book? \n 1)yes \n 2)no");
												scanner = new Scanner(System.in);
												a = scanner.nextInt();
												if (a == 1) {
													i3++;
												}
											} catch (InputMismatchException e) {
												System.err.println("Enter option 1 or 2");
											}
										} while (a != 2 && a != 1);

									}
								} else {
									System.err.println("Please enter existing bookId");
								}

							} catch (InputMismatchException e) {
								System.err.println("Enter numbers only");

							}

							catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (i3 == 0);
						int bookid = bean.getBookId();
						int i = service.deleteBook(bookid);
						if (i == 1) {
							System.out.println("Book deleted successfully");
						} else {

							System.out.println("Could not delete the book");
						}
						boolean choiceFlag3 = true;
						do {
							System.out.println("Do you wish to continue?\n Option-1)yes \n Option-2)no");							try {
								scanner = new Scanner(System.in);
								int choice2 = scanner.nextInt();
								if (choice2 == 2) {

									System.out.println("*** Thank you *** ");
									System.exit(0);
									break;
								} else if (choice2 == 1) {
									choiceFlag3 = false;
								} else {
									throw new BookException("Enter option 1 or 2");
								}

							} catch (InputMismatchException e) {
								System.err.println("Enter numbers only");

							} catch (BookException e) {
								System.err.println(e.getMessage());
							}
						} while (choiceFlag3);
						break;

					case 5:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;

					default:

						System.err.println("input should be 1 to 5");
						break;
					}

				} catch (InputMismatchException e) {
					System.err.println("input numbers only");
				}
			}
		} finally {
			scanner.close();
		}
	}
}
